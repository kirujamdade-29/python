# 71. Create a lambda function to find the product of two numbers.


product=lambda x,y:x*y
print(product(4,6))