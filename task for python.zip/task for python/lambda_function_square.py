# 32. Write a lambda function to find the square of a number.

a=lambda x:x**2
print(a(4))