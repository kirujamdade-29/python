# 14. Create a dictionary that stores student names as keys and their marks as values.


students_name={
    'vaibhav':77,
    'rajesh':76,
    'harish':80,
    'vinod':88,
    'avinash':83
}
print(f'student marks :- {students_name["vinod"]}')