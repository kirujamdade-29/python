# 79. Create a function to check if a list of numbers is sorted in ascending order.


def check_num(sort):
    return all(sort[i]<=sort[i+1] for i in range(len(sort)-1))
print(check_num([1,2,3,4]))