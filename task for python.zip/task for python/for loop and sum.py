# 4. Create a program to find the sum of numbers from 1 to 10 using a for loop.

sum=0
for num in range(1,11):
    sum=sum+num
print(sum)