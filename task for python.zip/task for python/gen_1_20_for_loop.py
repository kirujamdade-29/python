# 31. Create a program that generates a list of numbers from 1 to 20 using a loop.


List_gen=[]
for i in range(1,21):
    List_gen.append(i)
print(List_gen)