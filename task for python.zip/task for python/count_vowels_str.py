# 41. Write a program to count the number of vowels in a string.

count=0
string_name='the software developer'
for val in string_name:
    if val in 'aeiou':
        count+=1
print(f'Total vowels in string count numbers :-{count}')