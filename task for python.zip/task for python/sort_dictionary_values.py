# 44. Create a program that sorts a dictionary by its values.

dic={
    'a':3,
    'b':4,
    'c':2,
    'd':5,
    'f':1
}

value=sorted(dic.items(), key=lambda items: items[1])
print(value)