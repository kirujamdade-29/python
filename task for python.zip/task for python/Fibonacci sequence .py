# 34. Create a program to print the Fibonacci sequence up to a given number.

number=20
num1,num2=0,1
print(f'fibonacci sequence no :- {num1} {num2}')
for i in range(2, number):
    n3=num1+num2
    num1=num2
    num2=n3
    print(n3, end=' ')
