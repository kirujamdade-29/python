# 17. Create a set of numbers and check if a specific number is present in the set.



def check(n,num):
    return num in n
set1={1,4,8,9,5}
print(check(set1,5))