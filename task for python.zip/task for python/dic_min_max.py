# 38. Write a program to find the maximum and minimum elements in a dictionary.

dic={
    'marks_1':88,
    'marks_2':66,
    'marks_3':90
}
result=max(dic.values())
result_1=min(dic.values())
print(result)
print(result_1)