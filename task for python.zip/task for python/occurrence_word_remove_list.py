# 57. Write a program to remove the nth occurrence of a word from a list.


def remove_word(w1,words,n):
    add=[]
    count=0
    for i in w1:
        if i == words:
            count+=1
            if count == n:
                continue
        add.append(i)
    print(add)
a=['apple','banana','cherry','apple','cherry']
remove_word(a,'apple',3)