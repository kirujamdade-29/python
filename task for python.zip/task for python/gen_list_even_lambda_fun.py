# 59. Create a program that generates a list of even numbers using a loop and lambda function.

a1=list( filter(lambda x: x%2==0 , range(1,11)))
print(a1)