# 7. Create a program to find the factorial of a number using a while loop.

num=5
fact=1
while num>=1:
    fact *= num
    num -= 1
print(f'factorial is {fact}')

