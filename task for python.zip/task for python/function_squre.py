# 20. Create a function that returns the square of a given number.

def square(num):
    re=num**2
    print(re)
square(4)