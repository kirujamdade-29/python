# 18. Write a program to find the union of two sets.

set1={2,4,5,6}
set2={6,7,8,9}
result=set1.union(set2)
print(result)