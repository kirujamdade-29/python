# 29. Write a program to find the length of a list without using the `len()` function.

list_num=[1,5,9,3,66]
count=0
for i in list_num:
    count+=1
print(count)


# with function 

def length_check(length):
    count=0
    for X in length:
        count+=1
    print(count)
List_1=["sai","suresh","aditya"]
length_check(List_1)