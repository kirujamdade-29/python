# 39. Create a program that reverses a list of numbers.


num=[1,2,3,4,5,6,7]
result=num[::-1]
print(result)