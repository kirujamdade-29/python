# 11. Write a program to count the number of even and odd numbers in a list.



lists=[3,353,65,67,8,56,45,34,22,43,60]
even_count=0
odd_count=0
for val in lists:
    if val%2==0:
        even_count+=1
    else:
        odd_count+=1
print(f'even number total count {even_count}')
print(f'odd number total count {odd_count}')