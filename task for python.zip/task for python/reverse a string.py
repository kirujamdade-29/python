# 16. Write a program to reverse a string.



reverse_words='The software developer'
result=reverse_words[::-1]
print(result)
