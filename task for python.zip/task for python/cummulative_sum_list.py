# 52. Write a program to find the cumulative sum of a list.


# using function
result=[]
def cumulative_sum(list_num):
    total=0
    for i in list_num:
        total+=i
        result.append(total)
    print(result)
e=1,2,4,5,6
cumulative_sum(e)