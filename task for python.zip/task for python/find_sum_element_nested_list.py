# 65. Write a program to find the sum of elements in a nested list.


def sum_element(n_list):
    t=0
    for x in n_list:
        if  isinstance(x, list):
            t+=sum_element(x)
        else:
            t+=x
    return(t)
r=[1,[2,3],[4,[5,6]],7]
print(sum_element(r))