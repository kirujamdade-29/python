# 23. Write a program to convert a tuple into a list.


tuple_num=(55,77,34,65)
Convert_list=list(tuple_num)
print(tuple_num)
print(Convert_list)