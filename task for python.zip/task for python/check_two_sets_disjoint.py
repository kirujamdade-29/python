# 56. Create a program that checks if two sets are disjoint.


def set_check(s1, s2):
    result=s1.isdisjoint(s2)
    print(result)
s={1,2,3,4}
a={5,6,7,8}
set_check(s,a)