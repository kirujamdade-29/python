# 3. Write a program to check if a given number is even or odd.

number=23
if number%2==0:
    print(f'{number} is even number')
else:
    print(f'{number} is odd number')