# 69. Create a function to count the number of uppercase and lowercase letters in a string.


def count_words(word):
    uper_case= sum(1 for x in word if x.isupper())
    lower_case=sum(1 for x in word if x.islower())
    print(f'upper word count is :- {uper_case}')
    print(f'lower words count is :- {lower_case}')
count_words('Software')