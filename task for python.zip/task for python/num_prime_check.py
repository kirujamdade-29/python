# 33. Write a function to check if a number is prime.

n=18
if n>1:
    for i in range(2,n+1):
        if n%i==0:
            print(f'{n} is not prime')
            break
        else:
            print(f'{n} is a prime')
            break
else:
    print(f'{n} is not a prime')    
