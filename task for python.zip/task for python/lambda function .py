# 9. Write a lambda function to multiply two numbers

result=lambda x,y: x*y
print(result(4,5))

