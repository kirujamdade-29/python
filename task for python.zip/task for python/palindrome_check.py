# 67. Write a program to check if a number is a palindrome.


# num=999
# result=str(num)==str(num)[::-1]
# print(result)


num=982
if str(num)==str(num)[::-1]:
    print(f'Is palindrome Numbers {num}')
else:
    print(f'Not Palindrome Number {num}')