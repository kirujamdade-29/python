# 80. Write a program to split a list into two parts, where the first part contains even numbers and the second part contains odd numbers.


def even_odd(num):
    even=[n for n in num if n %2==0]
    odd=[n for n in num if n%2 != 0]
    print(f"even numbers :- {even}")
    print(f'odd numbers :- {odd}')

numbers=[1,2,3,4,6,7,8,9,10]
even_odd(numbers)