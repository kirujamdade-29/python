# 6. Write a program that takes a number and prints its multiplication table using a for loop.

for n in range(1,11):
    num=n*5
    print(num)



# 6. Write a program that takes a number and prints its multiplication table using a for loop and function 

def number():
    for i in range(1,11):
        result=i*2
        print(result)
number()
