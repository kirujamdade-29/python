# 35. Write a program to sort a list of strings in alphabetical order.


def sort_string(string):
    result=sorted(string)
    print(result)
st=['orange','apple','cherry','banana']
sort_string(st)