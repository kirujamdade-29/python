# 40. Write a program to find the sum of even numbers from 1 to 50.

for num in range(1,51):
    if num%2==0:
        print(num)
