# 55. Write a function that returns the first non-repeated character in a string.

string='varad'
for char in string:
    if string.count(char)==1:
        print(char)