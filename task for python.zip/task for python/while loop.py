# . Write a while loop that prints numbers from 1 to 5
a=1
while a<6:
    print(a)
    a+=1
