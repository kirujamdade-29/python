# 10. Create a list of integers and find the largest and smallest numbers in the list.



num=[44,53,64,65,28,88]
res=max(num) 
print(res) # largest number in list




re=min(num)
print(re) # smallest number in list