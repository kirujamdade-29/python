# 61. Create a program to merge two lists without duplicates.


list_1=[1,2,3,4,5]
list_2=[4,5,6,7,8]
result=list(set(list_1)|set(list_2))
print(result)