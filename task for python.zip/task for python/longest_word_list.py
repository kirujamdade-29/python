# 54. Create a program to find the longest word in a list of words.

log_list=['python','java','javascript','c programming']
result=max(log_list,key=len)
print(result)