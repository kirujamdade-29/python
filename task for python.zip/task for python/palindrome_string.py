# 28. Write a program to check if a string is a palindrome.


check='pop'
if check==check[::-1]:
    print('Is palindrome')
else:
    print('is not palindrome')
    