# 48. Write a function to merge two dictionaries.


dic_1={
    'name':'Harry',
    'age':22
}
dic_2={
    'name':'harsh',
    'age':23
}

marge_dic= {**dic_1, **dic_2}
print(marge_dic)