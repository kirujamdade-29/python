# 36. Create a set and add elements to it using a loop.

def create_set(add):
    num_set=set()
    for X in add:
        num_set.add(X)
    print(num_set)
element=[1,3,54,67]
create_set(element)