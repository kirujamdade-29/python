# 24. Create a program that takes two lists and returns their intersection.


list_num1=[77,88,99,33,55]
list_num2=[33,44,55,22,11]
convert_list_1=set(list_num1)
convert_list_2=set(list_num2)
result=convert_list_1.intersection(convert_list_2)
print(result)