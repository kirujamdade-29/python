# 49. Create a list comprehension to generate squares of numbers from 1 to 10.


list_square=[]
for square in range(1,11):
    re=square**2
    list_square.append(re)
print(list_square)