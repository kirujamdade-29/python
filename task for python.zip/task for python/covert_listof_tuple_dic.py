# 58. Write a function to convert a list of tuples into a dictionary.

def covert(list_tuple):
    result=dict(list_tuple)
    print(result)
a=[('a',1),('b',2)]
covert(a)