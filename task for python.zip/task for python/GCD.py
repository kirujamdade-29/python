# 76. Write a function to find the GCD (Greatest Common Divisor) of two numbers.

def greatest(c,d):
    while d:
        c,d=d, c%d
    print(c)
greatest(48,18)