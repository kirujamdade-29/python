# 45. Write a program to remove all occurrences of a specified element from a list.


num=[1,2,3,1,4]
element=1
for num in num:
    if num != element:
        print(num)