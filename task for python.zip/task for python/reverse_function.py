# 74. Create a function to reverse a list of tuples.

def reverse_list(list_tuples):
    return [i[::-1] for i in list_tuples]
p=[(122,344,54),(737,388,994)]
print(reverse_list(p))