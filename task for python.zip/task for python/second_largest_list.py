# 42. Create a program that finds the second largest number in a list.


second_num=[9288,1343,1545,1767,3433,8786]
result=sorted(second_num)
print(result[-2])


# with function  


def largest_check(num):
    result_n=sorted(num)
    print(result_n[-2])
num=[82,34,54,75,23]
largest_check(num)