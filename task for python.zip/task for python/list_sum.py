# Write a program to find the sum of all elements in a list.


list_num=[2,4,5,6]
result=sum(list_num)
print(result)