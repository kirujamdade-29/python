# 72. Write a program to create a new list with elements that are common to two given lists.


a=[2,3,4,5,6]
b=[3,5,7,8,9]
output=[]
for i in a:
    if i in b and i not in output:
        output.append(i)
print(output)