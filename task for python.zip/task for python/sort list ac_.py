# 15. Write a program to sort a list of numbers in ascending order.


list_num=[7,5,3,6,8,9,10,2,4,1]
list_num.sort()
print(list_num)