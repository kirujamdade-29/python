# 25. Write a program to count the frequency of each character in a string.


def frequency(words):
    values={}
    for val in words:
        if val in values:
            values[val]+=1
        else:
            values[val]=1
    print(values)
name="harish"
frequency(name)