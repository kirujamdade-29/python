# 78. Write a program to sort a list of tuples based on the second element.

def sort_element(second):
    result=sorted(second , key=lambda x:x[1])
    print(result)
    # second_result=result[1]
    # print(second_result)
a=[(1,3),(3,2),(2,1)]
sort_element(a)