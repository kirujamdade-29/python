# Write a program to print "Hello, Python!".

print('Hello, Python!')
