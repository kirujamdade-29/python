# 77. Create a program to check if a string contains only digits.


a='23543'
if a.isdigit():
    print('Yes Your number is digit')
else:
    print('your number not digit')