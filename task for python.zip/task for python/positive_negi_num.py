# 26. Write a function to check if a number is positive, negative, or zero.


def check_number(num):
    if num>0:
        print(f'{num} is Positive number')
    elif num<-1:
        print(f'{num} is negative Number')
    else:
        print(f'{num} is Zero number')
check_number(90)
