# 50. Write a program to find the common elements between two lists.


list_1=[1,2,3,4,5]
list_2=[2,3,5,6,7]
res=list(set(list_1) & set(list_2))
print(res)