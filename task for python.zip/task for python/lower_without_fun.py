# 63. Write a program to convert a string to lowercase without using built-in functions.


def covert_str(lower):
    lowercase=" "
    for char in lower:
        if 'A'<=char<='Z':
            lowercase+=chr(ord(char)+32)
        else:
            lowercase+=char
    print(lowercase)

covert_str('THE SOFTWARE DEVELOPER')