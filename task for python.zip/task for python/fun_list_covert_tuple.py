# 30. Write a function to convert a list of integers into a tuple.
def covert(num):
    result=tuple(num)
    print(result)

list_1=[1,5,6]
covert(list_1)