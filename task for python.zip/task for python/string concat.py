# 22. Create a list of strings and concatenate all the strings into one.

list_str=[2,3,4,5,6]
resu=str(list_str)
print(resu)
# for val in list_str:
# print(";".join(resu))