# 12. Create a program to check if an element exists in a tuple.


tuple_num=(8,3,5,2)
print(f'original tuple : {str(tuple_num)}')

num=5
r=num in tuple_num
print(f'does tuple contain required value ? :{str(r)}')