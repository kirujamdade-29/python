# 8. Write a program to calculate the area of a circle using a function.


def circle(find):
    pi=3.142
    result= pi*(find*find)
    print(f'area is {result}')
circle(5)