# 70. Write a program to find the mode of a list of numbers.



def mode_find(num):
    count={}
    for x in num:
        count[x] = count.get(x,0)+1
    find=max(count , key=count.get)
    print(find)
mode_find([11,2,3,4,5])