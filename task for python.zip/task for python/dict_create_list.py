# 75. Write a program to create a dictionary from two lists.


def create_dict(kays,value):
    result=dict(zip(kays,value))
    print(result)
key=['a','b','c']
val=[1,3,5]
create_dict(key,val)