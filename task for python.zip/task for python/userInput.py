# 2. Create a program that takes a user's name as input and prints a personalized greeting.

UserInput=input('Enter your name :- ')
print(f'Good Morning {UserInput}')