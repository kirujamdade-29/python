# 60. Write a program to check if a tuple is empty.


def check_tuple(empty):
    result=len(empty)==0
    print(result)
a=()
check_tuple(a)