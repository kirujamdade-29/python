# 43. Write a function to check if a given string is an anagram of another string.

def anagram_check(string_1,string_2):
    result=sorted(string_1)==sorted(string_2)
    print(result)
a='listen'
b='silent'
anagram_check(a,b)