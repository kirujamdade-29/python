# 68. Write a program to replace vowels in a string with a specified character.


def replace_vowels(vowels, replace):
    string_vowels='aeiouAEIOU'
    return ''.join(replace if c in string_vowels else c for c in vowels)

print(replace_vowels('Varad Pandit','@'))