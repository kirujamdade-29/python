# 64. Create a program that finds the common keys in two dictionaries.


def common_keys(d1,d2):
    return set(d1.keys()) & set(d2.keys())


a={'a':1,'b':2}
b={'b':4,'N':5}
print(common_keys(a,b))
