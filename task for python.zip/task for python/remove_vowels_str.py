# 73. Write a program to remove all the vowels from a string.

def vowels(words):
    store='aeiou'
    for i in words:
        if i not in store:
            print(i)
    

vowels('software developer')