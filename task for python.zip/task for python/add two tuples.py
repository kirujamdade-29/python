# 13. Write a program to add two tuples.


tuple_num1=(6,4,35,65)
tuple_num2=(6,54,56,7)
print(f"add Two tuples {tuple_num1 + tuple_num2}")