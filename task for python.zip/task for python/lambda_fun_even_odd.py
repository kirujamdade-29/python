# 47. Create a lambda function to check if a number is even or odd.


a1=lambda x: f'number is even {x}' if x%2==0 else f'number is odd {x}'
print(a1(4))
