# 66. Create a function to find the index of an element in a list.

def find_index(e,el):
    for i in range(len(e)):
        if e[i]==el:
            return i
    return -1

a=[30,40,50,60,70]
print(find_index(a,50))