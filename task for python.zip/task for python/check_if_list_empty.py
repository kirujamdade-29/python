# 51. Create a program to check if a list is empty.

num_empty=[]
num_list=[1,3,5]
result=len(num_empty)==0,'Empty list'
result2=len(num_list)==0
print(result)
print(result2)