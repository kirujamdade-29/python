# 37. Write a program to remove duplicates from a list.

li=[2,3,4,2,5,3,6,6,7]
result=set(li)
r=list(result)
print(r)