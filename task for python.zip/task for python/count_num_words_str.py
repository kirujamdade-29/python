# 53. Write a function to count the number of words in a string.


def count_number(words):
    result=len(words.split())
    print(result)
a="The software developer"
count_number(a)