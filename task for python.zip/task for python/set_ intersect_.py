# 19. Write a program to find the intersection of two sets.


Set1={2,3,5,6}
Set2={5,6,7,8}
result=Set1.intersection(Set2)
print(result)