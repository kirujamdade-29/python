# 46. Write a program to find the sum of digits of a given number.


def sum_digit(num):
    return sum(int(digit) for digit in str(num))
print(sum_digit(12346))


sum_num=2754
result=sum(int(num)for num in str(sum_num))
print(result)

