# 27. Create a dictionary with fruit names as keys and their colors as values.


fruit_color={
    'Apple':'red',
    'Banana':'yellow',
    'Orange':'Orange'
}
print(fruit_color)
print(fruit_color.keys())
print(fruit_color.values())